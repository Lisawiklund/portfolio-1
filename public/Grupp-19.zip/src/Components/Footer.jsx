import React from "react"

// Koden exporterar komponenten 'Footer'.
export default function Footer(){
    return <div style={{backgroundColor: "#003C80", height: "120px", color: "#fff"}}
    className="footer-copyright text-center py-3" > © 2023 Alla rättigheter förbehållna.
    </div>
   
};
